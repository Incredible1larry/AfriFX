
# AfriFX - Forex Rate Comparison Platform

## Overview
AfriFX is a full-stack web app for comparing forex rates across East African banks and international currencies, setting alerts, and calculating arbitrage profits.

---

## Setup Instructions

### Backend Setup

1. Install dependencies:
```
cd backend
npm install
```

2. Create `.env` file with:
```
MONGO_URI=your_mongodb_connection_string
JWT_SECRET=your_jwt_secret
SENDGRID_API_KEY=your_sendgrid_api_key
TWILIO_SID=your_twilio_sid
TWILIO_AUTH_TOKEN=your_twilio_auth_token
TWILIO_PHONE=your_twilio_phone_number
```

3. Run backend server:
```
npm run dev
```

4. Cron job runs automatically every 15 minutes to fetch forex rates.

---

### Frontend Setup

1. Install dependencies:
```
cd frontend
npm install
```

2. Create `.env` file with:
```
REACT_APP_API_URL=http://localhost:5000/api
```

3. Run frontend:
```
npm start
```

---

### Deployment

- Host backend on Railway/Render or VPS.
- Host frontend on Netlify or Vercel.
- Setup environment variables on the platform dashboard.

---

## Features

- Live forex rates dashboard
- Alerts with SMS/Email notifications
- Arbitrage profit calculator
- Admin dashboard with secure login

---

## Contact

For questions or support, contact: your-email@example.com
